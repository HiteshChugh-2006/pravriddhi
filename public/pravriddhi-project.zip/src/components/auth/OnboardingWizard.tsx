import React from 'react';
import { UserProfile, AuthUser } from '../../types';
import { CareerIntelligenceOnboarding } from './CareerIntelligenceOnboarding';

export interface OnboardingWizardProps {
  initialProfile: UserProfile;
  initialAuthUser?: AuthUser | null;
  onComplete: (updatedProfile: UserProfile) => void;
  onClose: () => void;
  onOpenSignIn?: () => void;
}

export const OnboardingWizard: React.FC<OnboardingWizardProps> = ({
  initialProfile,
  initialAuthUser,
  onComplete,
  onClose,
  onOpenSignIn
}) => {
  return (
    <CareerIntelligenceOnboarding
      initialProfile={initialProfile}
      initialAuthUser={initialAuthUser}
      onComplete={onComplete}
      onClose={onClose}
      onOpenSignIn={onOpenSignIn}
    />
  );
};
