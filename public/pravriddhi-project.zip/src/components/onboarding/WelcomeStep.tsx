import React from 'react';
import { Sparkles, ArrowRight, ShieldCheck, Target, TrendingUp, Cpu, Compass } from 'lucide-react';

interface WelcomeStepProps {
  onNext: () => void;
  onOpenSignIn?: () => void;
}

export const WelcomeStep: React.FC<WelcomeStepProps> = ({ onNext, onOpenSignIn }) => {
  return (
    <div className="max-w-3xl mx-auto py-4 sm:py-8 px-4 flex flex-col items-center text-center space-y-8 animate-in fade-in duration-300">
      
      {/* Brand & Badge */}
      <div className="space-y-3">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-50 border border-indigo-100 text-xs font-semibold text-indigo-700 shadow-2xs">
          <Sparkles className="w-3.5 h-3.5 text-indigo-600 animate-pulse" />
          <span>Next-Generation Career Intelligence</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
          Welcome to <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-indigo-700 to-violet-600">Pravriddhi</span>
        </h1>
        
        <h2 className="text-xl sm:text-2xl font-bold text-slate-800">
          Let's build your CareerTwin.
        </h2>

        <p className="text-sm sm:text-base text-slate-600 max-w-xl mx-auto leading-relaxed">
          Pravriddhi models your verified skills, discovers high-demand career pathways, and pinpoints exact skill gaps against live industry telemetry.
        </p>
      </div>

      {/* Central Animated CareerTwin Visualization */}
      <div className="relative w-full max-w-lg mx-auto py-8 px-6 rounded-3xl bg-gradient-to-b from-indigo-50/50 via-white to-violet-50/40 border border-indigo-100/80 shadow-lg shadow-indigo-950/5 overflow-hidden">
        {/* Ambient glow backdrop */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-gradient-to-tr from-indigo-400/15 via-violet-400/10 to-transparent rounded-full blur-3xl pointer-events-none" />

        <div className="relative flex flex-col items-center justify-center">
          
          {/* Orbital rings */}
          <div className="absolute w-64 h-64 rounded-full border border-dashed border-indigo-200/80 animate-[spin_40s_linear_infinite]" />
          <div className="absolute w-44 h-44 rounded-full border border-indigo-100 animate-[spin_25s_linear_infinite_reverse]" />

          {/* Center Pulse Core */}
          <div className="relative z-10 my-4 flex flex-col items-center">
            <div className="relative">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-violet-600 text-white flex items-center justify-center shadow-xl shadow-indigo-600/30 ring-8 ring-indigo-50 animate-pulse">
                <Cpu className="w-10 h-10" />
              </div>
              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full bg-emerald-500 text-white text-[10px] font-bold shadow-xs whitespace-nowrap">
                Live Twin Core
              </div>
            </div>
            <span className="mt-3 text-xs font-bold text-slate-900">Career Digital Twin</span>
            <span className="text-[11px] text-slate-400">Deterministic Skill Map</span>
          </div>

          {/* Connected Satellite Nodes */}
          <div className="w-full grid grid-cols-2 sm:grid-cols-3 gap-2.5 mt-6 z-10">
            {[
              { label: 'Core AI / PyTorch', metric: '94%', category: 'Machine Learning' },
              { label: 'System Design', metric: '86%', category: 'Software Architecture' },
              { label: 'RAG & Vectors', metric: '89%', category: 'Emerging Tech' },
              { label: 'MLOps Pipelines', metric: '72%', category: 'Infrastructure' },
              { label: 'Cloud Architecture', metric: '80%', category: 'Scalability' },
              { label: 'Live Telemetry', metric: '240k+', category: 'Market Signals' }
            ].map((node, i) => (
              <div
                key={i}
                className="p-2.5 rounded-xl bg-white/90 border border-slate-200/80 shadow-2xs hover:border-indigo-300 hover:shadow-xs transition-all flex flex-col text-left"
              >
                <div className="flex items-center justify-between text-[10px] text-slate-400 font-semibold mb-0.5">
                  <span className="truncate">{node.category}</span>
                  <span className="font-mono text-indigo-600 font-bold">{node.metric}</span>
                </div>
                <span className="text-xs font-bold text-slate-800 truncate">{node.label}</span>
              </div>
            ))}
          </div>

        </div>

        {/* Telemetry pill */}
        <div className="mt-6 pt-3 border-t border-slate-100 flex items-center justify-center gap-4 text-[11px] text-slate-500 flex-wrap">
          <span className="flex items-center gap-1 font-medium">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            Evidence-Verified
          </span>
          <span>·</span>
          <span className="flex items-center gap-1 font-medium">
            <TrendingUp className="w-3.5 h-3.5 text-indigo-600" />
            Real-Time Demand
          </span>
          <span>·</span>
          <span className="flex items-center gap-1 font-medium">
            <Target className="w-3.5 h-3.5 text-violet-600" />
            Goal Alignment
          </span>
        </div>
      </div>

      {/* CTA Section */}
      <div className="flex flex-col sm:flex-row items-center justify-center gap-3 w-full max-w-sm">
        <button
          onClick={onNext}
          className="w-full py-4 px-8 rounded-2xl bg-gradient-to-r from-indigo-600 via-indigo-700 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white font-bold text-sm shadow-lg shadow-indigo-600/25 hover:shadow-xl transition-all flex items-center justify-center gap-2 group cursor-pointer"
        >
          <span>Build My CareerTwin</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </button>

        {onOpenSignIn && (
          <button
            onClick={onOpenSignIn}
            className="w-full py-3 px-4 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors"
          >
            Already have an account? Sign in
          </button>
        )}
      </div>

    </div>
  );
};
