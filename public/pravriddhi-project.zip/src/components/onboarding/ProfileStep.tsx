import React, { useState } from 'react';
import { User, GraduationCap, Calendar, Award, ArrowRight, ArrowLeft, CheckCircle2, Sparkles, Building2, MapPin } from 'lucide-react';

interface ProfileStepProps {
  name: string;
  setName: (v: string) => void;
  education: string;
  setEducation: (v: string) => void;
  degree: string;
  setDegree: (v: string) => void;
  gradYear: string;
  setGradYear: (v: string) => void;
  experienceLevel: string;
  setExperienceLevel: (v: string) => void;
  location: string;
  setLocation: (v: string) => void;
  onNext: () => void;
  onBack: () => void;
}

export const ProfileStep: React.FC<ProfileStepProps> = ({
  name,
  setName,
  education,
  setEducation,
  degree,
  setDegree,
  gradYear,
  setGradYear,
  experienceLevel,
  setExperienceLevel,
  location,
  setLocation,
  onNext,
  onBack
}) => {
  const [error, setError] = useState<string | null>(null);

  const experienceOptions = [
    { id: 'Student / New Grad', label: 'Student / New Grad', sub: 'Looking for initial entry into industry' },
    { id: '1 – 2 Years', label: '1 – 2 Years', sub: 'Junior / Early Career Engineer' },
    { id: '3 – 5 Years', label: '3 – 5 Years', sub: 'Mid-Level Professional' },
    { id: '5+ Years', label: '5+ Years', sub: 'Senior / Specialist / Lead' }
  ];

  const handleContinue = () => {
    if (!name.trim()) {
      setError('Please provide your name to personalize your CareerTwin.');
      return;
    }
    if (!degree.trim()) {
      setError('Please enter your field of study or degree.');
      return;
    }
    if (!education.trim()) {
      setError('Please provide your school, university, or background.');
      return;
    }
    setError(null);
    onNext();
  };

  const getInitials = (n: string) => {
    if (!n.trim()) return 'CT';
    const parts = n.trim().split(/\s+/);
    if (parts.length >= 2) {
      return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return n.slice(0, 2).toUpperCase();
  };

  return (
    <div className="max-w-4xl mx-auto py-4 px-4 space-y-6 animate-in fade-in duration-300">
      
      {/* Step Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-100 text-xs font-semibold text-indigo-700">
          <User className="w-3.5 h-3.5" />
          <span>Screen 2 of 7 · About You</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Let's establish your foundation.
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 max-w-lg mx-auto">
          Every field you complete immediately anchors your CareerTwin in verified background context.
        </p>
      </div>

      {error && (
        <div className="max-w-xl mx-auto p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs font-medium text-center">
          {error}
        </div>
      )}

      {/* Two Column Layout: Progressive Form (Left) & Real-time Animated Twin Identity (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Form Controls (7 cols) */}
        <div className="lg:col-span-7 space-y-5 bg-white/80 rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-xs">
          
          {/* Field 1: Name */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center justify-between">
              <span>Full Name</span>
              <span className="text-slate-400 font-normal lowercase">Required</span>
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  setError(null);
                }}
                placeholder="e.g. Alex Morgan"
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 bg-slate-50/50 text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all outline-hidden font-medium"
              />
            </div>
          </div>

          {/* Field 2 & 3: Degree & Education */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center justify-between">
                <span>Degree / Field</span>
                <span className="text-slate-400 font-normal lowercase">Required</span>
              </label>
              <div className="relative">
                <GraduationCap className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={degree}
                  onChange={(e) => {
                    setDegree(e.target.value);
                    setError(null);
                  }}
                  placeholder="e.g. Computer Science, Data Science"
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 bg-slate-50/50 text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all outline-hidden font-medium"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center justify-between">
                <span>Institution / School</span>
                <span className="text-slate-400 font-normal lowercase">Required</span>
              </label>
              <div className="relative">
                <Building2 className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={education}
                  onChange={(e) => {
                    setEducation(e.target.value);
                    setError(null);
                  }}
                  placeholder="e.g. Stanford, UC Berkeley, IIT"
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 bg-slate-50/50 text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all outline-hidden font-medium"
                />
              </div>
            </div>
          </div>

          {/* Field 4 & 5: Grad Year & Location */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Current Year / Grad Year
              </label>
              <div className="relative">
                <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <select
                  value={gradYear}
                  onChange={(e) => setGradYear(e.target.value)}
                  aria-label="Graduation Year"
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 bg-slate-50/50 text-xs sm:text-sm text-slate-900 focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all outline-hidden font-medium"
                >
                  <option value="2027+">2027 or later (Undergraduate / Graduate)</option>
                  <option value="2026">2026 (Senior / Graduating)</option>
                  <option value="2025">2025 (Recent Graduate)</option>
                  <option value="2024">2024 (Class of 2024)</option>
                  <option value="2023 & Prior">2023 or earlier (Experienced)</option>
                </select>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Location / Preferred Region
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. San Francisco, CA or Remote"
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 bg-slate-50/50 text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all outline-hidden font-medium"
                />
              </div>
            </div>
          </div>

          {/* Field 6: Experience Tier */}
          <div className="space-y-2 pt-1">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Experience Level
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {experienceOptions.map((opt) => {
                const selected = experienceLevel === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setExperienceLevel(opt.id)}
                    className={`p-3 rounded-2xl border text-left transition-all ${
                      selected
                        ? 'bg-indigo-50/90 border-indigo-600 shadow-2xs ring-1 ring-indigo-500'
                        : 'bg-white border-slate-200/90 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-slate-900">{opt.label}</span>
                      {selected && <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />}
                    </div>
                    <span className="text-[11px] text-slate-500 block mt-0.5">{opt.sub}</span>
                  </button>
                );
              })}
            </div>
          </div>

        </div>

        {/* Live Identity Card Visualization (5 cols) */}
        <div className="lg:col-span-5 sticky top-6">
          <div className="p-6 rounded-3xl bg-gradient-to-br from-indigo-50/70 via-white to-violet-50/60 border border-indigo-100 shadow-md space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-indigo-100/70">
              <span className="text-[10px] font-bold text-indigo-700 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                <span>CareerTwin Identity Node</span>
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                Compiling
              </span>
            </div>

            {/* Avatar & Dynamic Title */}
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 text-white font-black text-xl flex items-center justify-center shadow-md shadow-indigo-600/20 ring-4 ring-indigo-50 transition-all duration-300">
                {getInitials(name)}
              </div>
              <div className="min-w-0">
                <h3 className="font-extrabold text-base text-slate-900 truncate">
                  {name || 'Your Name'}
                </h3>
                <p className="text-xs text-slate-500 truncate">
                  {degree || 'Field of Study'}
                </p>
                <p className="text-[11px] text-indigo-600 font-semibold truncate mt-0.5">
                  {education || 'Institution / Background'} ({gradYear})
                </p>
              </div>
            </div>

            {/* Live Fact Badges */}
            <div className="space-y-2 pt-2 text-xs">
              <div className="p-2.5 rounded-xl bg-white/90 border border-slate-200/70 flex items-center justify-between">
                <span className="text-slate-500 font-medium">Experience Phase</span>
                <span className="font-bold text-slate-800">{experienceLevel}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-white/90 border border-slate-200/70 flex items-center justify-between">
                <span className="text-slate-500 font-medium">Market Location</span>
                <span className="font-bold text-slate-800">{location || 'Remote'}</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 italic text-center pt-1">
              "Pravriddhi roots your CareerTwin in verified facts, not aspirational keywords."
            </p>
          </div>
        </div>

      </div>

      {/* Navigation Controls */}
      <div className="pt-4 flex items-center justify-between border-t border-slate-200">
        <button
          onClick={onBack}
          className="px-5 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 font-semibold text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back</span>
        </button>

        <button
          onClick={handleContinue}
          className="px-7 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition-all flex items-center gap-2 group cursor-pointer"
        >
          <span>Continue to Skills</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
        </button>
      </div>

    </div>
  );
};
