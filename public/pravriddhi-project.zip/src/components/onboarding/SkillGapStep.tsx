import React, { useState, useEffect } from 'react';
import { Target, CheckCircle2, AlertCircle, ArrowRight, ArrowLeft, TrendingUp, ShieldCheck, Sparkles, HelpCircle, Layers } from 'lucide-react';
import { OnboardingSkill } from './SkillsStep';
import { ONBOARDING_ROLES } from './CareerGoalStep';

interface SkillGapStepProps {
  skills: OnboardingSkill[];
  targetRoleTitle: string;
  onNext: () => void;
  onBack: () => void;
}

export const SkillGapStep: React.FC<SkillGapStepProps> = ({
  skills,
  targetRoleTitle,
  onNext,
  onBack
}) => {
  // Find role definition
  const targetRole = ONBOARDING_ROLES.find(
    (r) => r.title.toLowerCase() === targetRoleTitle.toLowerCase()
  ) || ONBOARDING_ROLES[0];

  // Dynamic categorisation
  // Strong: present in skills with proficiency >= 65
  const strongSkills = targetRole.requiredSkills.filter((req) =>
    skills.some((s) => s.name.toLowerCase() === req.toLowerCase() && s.proficiency >= 65)
  );

  // Developing: present in skills with proficiency < 65
  const developingSkills = targetRole.requiredSkills.filter((req) =>
    skills.some((s) => s.name.toLowerCase() === req.toLowerCase() && s.proficiency < 65)
  );

  // Missing: required by target role, not yet in user skills
  const missingSkills = targetRole.requiredSkills.filter(
    (req) => !skills.some((s) => s.name.toLowerCase() === req.toLowerCase())
  );

  // Computed alignment percentage
  const totalRequired = Math.max(1, targetRole.requiredSkills.length);
  const alignmentScore = Math.min(
    96,
    Math.max(
      20,
      Math.round(((strongSkills.length * 1.0 + developingSkills.length * 0.5) / totalRequired) * 100)
    )
  );

  return (
    <div className="max-w-4xl mx-auto py-4 px-4 space-y-6 animate-in fade-in duration-300">
      
      {/* Step Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-100 text-xs font-semibold text-indigo-700">
          <Layers className="w-3.5 h-3.5" />
          <span>Screen 5 of 7 · Skill Gap Analysis</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Benchmark against {targetRole.title}
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 max-w-xl mx-auto">
          Pravriddhi has evaluated your competencies against 15,000+ live market requisitions to identify strong matches and gaps.
        </p>
      </div>

      {/* Visual Workflow: YOUR SKILLS → CAREER REQUIREMENTS → SKILL GAP */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-50/90 border border-slate-200/90 flex flex-col md:flex-row items-center justify-between gap-3 text-center">
        
        <div className="flex-1 p-3 rounded-2xl bg-white border border-slate-200 shadow-2xs w-full">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">1. Your Skills</span>
          <span className="text-sm font-bold text-slate-900">{skills.length} Competencies</span>
          <span className="text-[11px] text-slate-500 block truncate mt-0.5">
            {skills.slice(0, 3).map((s) => s.name).join(', ')}...
          </span>
        </div>

        <div className="text-indigo-400 font-bold hidden md:block">→</div>
        <div className="text-indigo-400 font-bold md:hidden">↓</div>

        <div className="flex-1 p-3 rounded-2xl bg-white border border-slate-200 shadow-2xs w-full">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">2. Role Requirements</span>
          <span className="text-sm font-bold text-indigo-700">{targetRole.title}</span>
          <span className="text-[11px] text-slate-500 block truncate mt-0.5">
            {targetRole.requiredSkills.length} Core Requirements
          </span>
        </div>

        <div className="text-indigo-400 font-bold hidden md:block">→</div>
        <div className="text-indigo-400 font-bold md:hidden">↓</div>

        <div className="flex-1 p-3 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 text-white shadow-md shadow-indigo-600/20 w-full">
          <span className="text-[10px] font-bold text-indigo-200 uppercase tracking-wider block">3. Skill Gap Fit</span>
          <span className="text-sm font-mono font-black">{alignmentScore}% Alignment</span>
          <span className="text-[11px] text-indigo-100 block mt-0.5">
            {missingSkills.length} Missing to Bridge
          </span>
        </div>

      </div>

      {/* 3 Clear Categories: ✓ Strong, ◐ Developing, ○ Missing */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Category 1: Strong (✓) */}
        <div className="p-5 rounded-3xl bg-white border border-emerald-200/90 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-sm">
                ✓
              </div>
              <h3 className="font-bold text-sm text-emerald-950">Strong Competence</h3>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
              {strongSkills.length}
            </span>
          </div>

          <p className="text-[11px] text-slate-500">
            Skills with demonstrated high proficiency ($\ge 65\%$) matching this role.
          </p>

          <div className="space-y-1.5 pt-1">
            {strongSkills.length > 0 ? (
              strongSkills.map((s) => (
                <div
                  key={s}
                  className="p-2.5 rounded-xl bg-emerald-50/70 border border-emerald-100 text-emerald-900 text-xs font-semibold flex items-center justify-between"
                >
                  <span>{s}</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                </div>
              ))
            ) : (
              <div className="p-3 rounded-xl bg-slate-50 text-slate-400 text-xs italic text-center">
                None qualified above 65% yet
              </div>
            )}
          </div>
        </div>

        {/* Category 2: Developing (◐) */}
        <div className="p-5 rounded-3xl bg-white border border-sky-200/90 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-xl bg-sky-100 text-sky-800 flex items-center justify-center font-bold text-sm">
                ◐
              </div>
              <h3 className="font-bold text-sm text-sky-950">Developing Skills</h3>
            </div>
            <span className="text-xs font-mono font-bold text-sky-700 bg-sky-50 px-2 py-0.5 rounded-full border border-sky-100">
              {developingSkills.length}
            </span>
          </div>

          <p className="text-[11px] text-slate-500">
            Skills you have at foundational stage that can be leveled up to production grade.
          </p>

          <div className="space-y-1.5 pt-1">
            {developingSkills.length > 0 ? (
              developingSkills.map((s) => (
                <div
                  key={s}
                  className="p-2.5 rounded-xl bg-sky-50/70 border border-sky-100 text-sky-900 text-xs font-semibold flex items-center justify-between"
                >
                  <span>{s}</span>
                  <span className="text-[10px] font-mono text-sky-700 bg-sky-100 px-1.5 py-0.5 rounded">
                    Foundational
                  </span>
                </div>
              ))
            ) : (
              <div className="p-3 rounded-xl bg-slate-50 text-slate-400 text-xs italic text-center">
                No partial skills identified
              </div>
            )}
          </div>
        </div>

        {/* Category 3: Missing (○) - Animated appearing */}
        <div className="p-5 rounded-3xl bg-white border border-amber-200/90 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold text-sm">
                ○
              </div>
              <h3 className="font-bold text-sm text-amber-950">Missing Skills (Gaps)</h3>
            </div>
            <span className="text-xs font-mono font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-100">
              {missingSkills.length}
            </span>
          </div>

          <p className="text-[11px] text-slate-500">
            Required industry competencies not yet verified in your profile.
          </p>

          <div className="space-y-1.5 pt-1">
            {missingSkills.length > 0 ? (
              missingSkills.map((s, idx) => (
                <div
                  key={s}
                  style={{ animationDelay: `${idx * 150}ms` }}
                  className="p-2.5 rounded-xl bg-amber-50/70 border border-amber-200/70 text-amber-950 text-xs font-semibold flex items-center justify-between animate-in fade-in slide-in-from-bottom-2 duration-300"
                >
                  <span>+ {s}</span>
                  <span className="text-[10px] text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded font-mono">
                    Priority Gap
                  </span>
                </div>
              ))
            ) : (
              <div className="p-3 rounded-xl bg-emerald-50 text-emerald-800 text-xs font-medium text-center">
                All role competencies covered!
              </div>
            )}
          </div>
        </div>

      </div>

      {/* Skill Gap Takeaway Note */}
      <div className="p-4 rounded-2xl bg-indigo-50/70 border border-indigo-100 flex items-center gap-3 text-xs text-slate-700">
        <Sparkles className="w-4 h-4 text-indigo-600 shrink-0" />
        <span>
          Bridging your top <strong>{missingSkills.slice(0, 2).join(' and ')}</strong> gaps in the What-If Simulator will boost your candidate match above <strong>88%</strong>.
        </span>
      </div>

      {/* Navigation Controls */}
      <div className="pt-4 flex items-center justify-between border-t border-slate-200">
        <button
          onClick={onBack}
          className="px-5 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 font-semibold text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back</span>
        </button>

        <button
          onClick={onNext}
          className="px-8 py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition-all flex items-center gap-2 group cursor-pointer"
        >
          <span>Construct CareerTwin</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
        </button>
      </div>

    </div>
  );
};
