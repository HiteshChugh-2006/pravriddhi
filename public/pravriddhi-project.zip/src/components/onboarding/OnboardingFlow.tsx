import React, { useState } from 'react';
import { UserProfile, UserSkill, AuthUser } from '../../types';
import { WelcomeStep } from './WelcomeStep';
import { ProfileStep } from './ProfileStep';
import { SkillsStep, OnboardingSkill } from './SkillsStep';
import { CareerGoalStep, ONBOARDING_ROLES } from './CareerGoalStep';
import { SkillGapStep } from './SkillGapStep';
import { BuildingCareerTwinStep } from './BuildingCareerTwinStep';
import { CareerTwinReadyStep } from './CareerTwinReadyStep';
import { Sparkles, ShieldCheck, LogIn } from 'lucide-react';
import { authService } from '../../services/firebaseAuth';

interface OnboardingFlowProps {
  initialProfile: UserProfile;
  authUser: AuthUser | null;
  onComplete: (updatedProfile: UserProfile) => void;
  onOpenSignIn?: () => void;
}

export const OnboardingFlow: React.FC<OnboardingFlowProps> = ({
  initialProfile,
  authUser,
  onComplete,
  onOpenSignIn
}) => {
  // Step state: 1 to 7
  const [currentStep, setCurrentStep] = useState<number>(1);
  const totalSteps = 7;

  // Profile data gathered through the journey
  const [name, setName] = useState<string>(
    initialProfile.name || authUser?.displayName || ''
  );
  const [degree, setDegree] = useState<string>(
    initialProfile.education[0]?.degree || 'Computer Science & AI'
  );
  const [education, setEducation] = useState<string>(
    initialProfile.education[0]?.school || 'University of California, Berkeley'
  );
  const [gradYear, setGradYear] = useState<string>(
    initialProfile.education[0]?.year || '2026'
  );
  const [experienceLevel, setExperienceLevel] = useState<string>('Student / New Grad');
  const [location, setLocation] = useState<string>(
    initialProfile.location || 'San Francisco Bay Area, CA'
  );

  // Skills state
  const [skills, setSkills] = useState<OnboardingSkill[]>(() => {
    if (initialProfile.skills && initialProfile.skills.length > 0) {
      return initialProfile.skills.map((s) => ({
        name: s.name,
        category: s.category,
        proficiency: s.proficiency,
        type: s.type
      }));
    }
    return [
      { name: 'Python', category: 'Core AI/ML', proficiency: 85, type: 'demonstrated' },
      { name: 'Machine Learning', category: 'Core AI/ML', proficiency: 75, type: 'demonstrated' },
      { name: 'SQL', category: 'Data & Analytics', proficiency: 80, type: 'demonstrated' },
      { name: 'Deep Learning (PyTorch)', category: 'Core AI/ML', proficiency: 70, type: 'demonstrated' }
    ];
  });

  // Target Career Goal
  const [targetRoleTitle, setTargetRoleTitle] = useState<string>(
    initialProfile.targetRole || 'ML Engineer'
  );

  const stepLabels = [
    'Welcome',
    'About You',
    'Your Skills',
    'Career Goal',
    'Skill Gap',
    'Building CareerTwin',
    'Your CareerTwin is Ready'
  ];

  // Final submission into existing profile system
  const handleFinalizeAndEnterDashboard = () => {
    const targetRoleObj = ONBOARDING_ROLES.find(
      (r) => r.title.toLowerCase() === targetRoleTitle.toLowerCase()
    ) || ONBOARDING_ROLES[0];

    const strongCount = targetRoleObj.requiredSkills.filter((req) =>
      skills.some((s) => s.name.toLowerCase() === req.toLowerCase() && s.proficiency >= 65)
    ).length;

    const developingCount = targetRoleObj.requiredSkills.filter((req) =>
      skills.some((s) => s.name.toLowerCase() === req.toLowerCase() && s.proficiency < 65)
    ).length;

    const alignment = Math.min(
      96,
      Math.max(
        25,
        Math.round(((strongCount * 1.0 + developingCount * 0.5) / Math.max(1, targetRoleObj.requiredSkills.length)) * 100)
      )
    );

    const formattedSkills: UserSkill[] = skills.map((s, idx) => ({
      id: `sk_onb_${Date.now()}_${idx}`,
      name: s.name,
      category: s.category,
      proficiency: s.proficiency,
      confidence: s.proficiency >= 80 ? 'High' : s.proficiency >= 60 ? 'Moderate' : 'Emerging',
      type: s.type,
      yearsExp: s.proficiency >= 80 ? 3 : s.proficiency >= 60 ? 2 : 1,
      marketDemand: s.proficiency >= 75 ? 'Surging' : 'High',
      lastPracticed: 'Recently',
      evidence: [
        {
          id: `ev_onb_${Date.now()}_${idx}`,
          type: 'Project',
          title: `Demonstrated technical competency in ${s.name}`
        }
      ]
    }));

    const updatedProfile: UserProfile = {
      ...initialProfile,
      id: authUser?.uid || initialProfile.id || `usr_${Date.now()}`,
      name: name.trim() || 'Alex Morgan',
      email: authUser?.email || initialProfile.email || '',
      title: `${degree.trim() || 'Engineer'} · Aspiring ${targetRoleTitle}`,
      location: location.trim() || 'San Francisco, CA',
      targetRole: targetRoleTitle,
      targetRoleAlignment: alignment,
      alignmentTrend: 8,
      summary: `${name.trim() || 'Alex Morgan'} is an ambitious technologist targeting ${targetRoleTitle}. Their verified CareerTwin models demonstrated proficiencies across ${skills.slice(0, 3).map((s) => s.name).join(', ')}.`,
      skills: formattedSkills,
      education: [
        {
          id: `edu_onb_${Date.now()}`,
          degree: degree.trim(),
          school: education.trim(),
          year: gradYear.trim(),
          gpa: '3.8'
        }
      ],
      projects: initialProfile.projects.length > 0 ? initialProfile.projects : [
        {
          id: `proj_onb_${Date.now()}`,
          title: `${targetRoleTitle} Production Pipeline`,
          description: `Engineered scalable end-to-end service using ${skills.slice(0, 3).map((s) => s.name).join(', ')}.`,
          tech: skills.slice(0, 4).map((s) => s.name),
          verified: true
        }
      ],
      experience: initialProfile.experience.length > 0 ? initialProfile.experience : [
        {
          id: `exp_onb_${Date.now()}`,
          title: 'Software & ML Engineering Apprentice',
          company: 'Applied AI Systems Lab',
          location: location.trim(),
          startDate: '2024',
          endDate: 'Present',
          bullets: [
            `Built scalable pipelines and inference endpoints using ${skills.slice(0, 3).map((s) => s.name).join(', ')}.`,
            'Monitored model latency, drift, and throughput under real workloads.'
          ],
          skillsUsed: skills.slice(0, 3).map((s) => s.name)
        }
      ],
      onboardingCompleted: true
    };

    // Commit to persistence
    authService.saveProfileToDatabase(updatedProfile);
    onComplete(updatedProfile);
  };

  return (
    <div className="min-h-screen ambient-bg flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      
      {/* Immersive Dedicated Onboarding Top Bar */}
      <header className="sticky top-0 z-40 w-full glass-nav border-b border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-violet-500 flex items-center justify-center text-white shadow-xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold tracking-tight text-slate-900 leading-none">
                Pravriddhi
              </span>
              <span className="text-[10px] font-semibold text-indigo-600 tracking-wider uppercase mt-0.5">
                CareerTwin Onboarding
              </span>
            </div>
          </div>

          {/* Stepper Progress Meter */}
          <div className="flex items-center gap-4">
            <div className="hidden sm:flex flex-col text-right">
              <span className="text-xs font-bold text-slate-900">
                Step {currentStep} of {totalSteps}
              </span>
              <span className="text-[11px] text-indigo-600 font-medium">
                {stepLabels[currentStep - 1]}
              </span>
            </div>

            {/* Micro Progress Bar */}
            <div className="w-24 sm:w-36 bg-slate-100 h-2 rounded-full overflow-hidden border border-slate-200/60">
              <div
                className="h-full bg-gradient-to-r from-indigo-600 via-indigo-500 to-violet-600 rounded-full transition-all duration-300 ease-out"
                style={{ width: `${(currentStep / totalSteps) * 100}%` }}
              />
            </div>

            {/* Auth / Sign In trigger if not logged in */}
            {onOpenSignIn && !authUser && (
              <button
                onClick={onOpenSignIn}
                className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold transition-colors"
              >
                <LogIn className="w-3.5 h-3.5 text-indigo-600" />
                <span>Sign In</span>
              </button>
            )}
          </div>

        </div>
      </header>

      {/* Main Interactive Screen Content */}
      <main className="flex-1 w-full max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8 flex flex-col justify-center">
        
        {/* Screen 1: Welcome */}
        {currentStep === 1 && (
          <WelcomeStep
            onNext={() => setCurrentStep(2)}
            onOpenSignIn={onOpenSignIn}
          />
        )}

        {/* Screen 2: About You */}
        {currentStep === 2 && (
          <ProfileStep
            name={name}
            setName={setName}
            education={education}
            setEducation={setEducation}
            degree={degree}
            setDegree={setDegree}
            gradYear={gradYear}
            setGradYear={setGradYear}
            experienceLevel={experienceLevel}
            setExperienceLevel={setExperienceLevel}
            location={location}
            setLocation={setLocation}
            onNext={() => setCurrentStep(3)}
            onBack={() => setCurrentStep(1)}
          />
        )}

        {/* Screen 3: Your Skills */}
        {currentStep === 3 && (
          <SkillsStep
            userName={name}
            skills={skills}
            setSkills={setSkills}
            onNext={() => setCurrentStep(4)}
            onBack={() => setCurrentStep(2)}
          />
        )}

        {/* Screen 4: Career Goal */}
        {currentStep === 4 && (
          <CareerGoalStep
            selectedRoleTitle={targetRoleTitle}
            setSelectedRoleTitle={setTargetRoleTitle}
            onNext={() => setCurrentStep(5)}
            onBack={() => setCurrentStep(3)}
          />
        )}

        {/* Screen 5: Skill Gap */}
        {currentStep === 5 && (
          <SkillGapStep
            skills={skills}
            targetRoleTitle={targetRoleTitle}
            onNext={() => setCurrentStep(6)}
            onBack={() => setCurrentStep(4)}
          />
        )}

        {/* Screen 6: Building Your CareerTwin */}
        {currentStep === 6 && (
          <BuildingCareerTwinStep
            onComplete={() => setCurrentStep(7)}
          />
        )}

        {/* Screen 7: Your CareerTwin is Ready */}
        {currentStep === 7 && (
          <CareerTwinReadyStep
            name={name}
            degree={degree}
            education={education}
            gradYear={gradYear}
            experienceLevel={experienceLevel}
            location={location}
            skills={skills}
            targetRoleTitle={targetRoleTitle}
            onEnterDashboard={handleFinalizeAndEnterDashboard}
          />
        )}

      </main>

      {/* Subtle Onboarding Footer */}
      <footer className="py-4 border-t border-slate-200/60 bg-white/40 text-center text-xs text-slate-400">
        Pravriddhi Career Digital Twin Engine · Understand Skills · Predict Demand · Simulate Careers
      </footer>

    </div>
  );
};
