import React, { useState, useEffect } from 'react';
import { Cpu, CheckCircle2, Loader2, Sparkles, Layers, ArrowRight, ShieldCheck, Target } from 'lucide-react';

interface BuildingCareerTwinStepProps {
  onComplete: () => void;
}

interface Phase {
  title: string;
  detail: string;
  durationMs: number;
}

const PHASES: Phase[] = [
  {
    title: 'Analyzing your profile & education...',
    detail: 'Validating academic background and professional experience tier.',
    durationMs: 700
  },
  {
    title: 'Mapping your skills & competency nodes...',
    detail: 'Vectorizing technical capabilities into the dynamic CareerTwin graph.',
    durationMs: 800
  },
  {
    title: 'Understanding your career goal...',
    detail: 'Retrieving live market telemetry and compensation benchmarks.',
    durationMs: 750
  },
  {
    title: 'Calculating your skill gaps...',
    detail: 'Cross-referencing required vs demonstrated competencies.',
    durationMs: 800
  },
  {
    title: 'Compiling your CareerTwin identity...',
    detail: 'Finalizing deterministic digital twin and activating personalized dashboard.',
    durationMs: 850
  }
];

export const BuildingCareerTwinStep: React.FC<BuildingCareerTwinStepProps> = ({ onComplete }) => {
  const [activePhaseIndex, setActivePhaseIndex] = useState(0);
  const [completedPhases, setCompletedPhases] = useState<number[]>([]);
  const [isFinished, setIsFinished] = useState(false);

  useEffect(() => {
    let currentIdx = 0;

    const runNextPhase = () => {
      if (currentIdx < PHASES.length) {
        setActivePhaseIndex(currentIdx);
        setTimeout(() => {
          setCompletedPhases((prev) => [...prev, currentIdx]);
          currentIdx += 1;
          if (currentIdx < PHASES.length) {
            runNextPhase();
          } else {
            setIsFinished(true);
            // Smoothly auto-advance after brief completion pause
            setTimeout(() => {
              onComplete();
            }, 1000);
          }
        }, PHASES[currentIdx].durationMs);
      }
    };

    runNextPhase();
  }, []);

  const overallProgress = Math.round(((completedPhases.length) / PHASES.length) * 100);

  return (
    <div className="max-w-2xl mx-auto py-8 px-4 flex flex-col items-center text-center space-y-8 animate-in fade-in duration-300">
      
      {/* Top Header */}
      <div className="space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-100 text-xs font-semibold text-indigo-700">
          <Cpu className="w-3.5 h-3.5 text-indigo-600 animate-spin" />
          <span>Screen 6 of 7 · Synthesizing CareerTwin</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Building Your CareerTwin
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto">
          Please wait while Pravriddhi synthesizes your verified competencies into an active digital twin.
        </p>
      </div>

      {/* Center Dynamic Construction Reactor */}
      <div className="w-full p-6 sm:p-8 rounded-3xl bg-gradient-to-b from-indigo-50/60 via-white to-violet-50/50 border border-indigo-100 shadow-xl space-y-6">
        
        {/* Core Pulsing Reactor Icon */}
        <div className="relative flex justify-center">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-violet-600 text-white flex items-center justify-center shadow-lg shadow-indigo-600/30 ring-8 ring-indigo-50 animate-pulse">
            <Cpu className="w-10 h-10" />
          </div>
          <div className="absolute -bottom-2 px-3 py-0.5 rounded-full bg-indigo-900 text-white text-[10px] font-mono font-bold shadow-xs">
            {overallProgress}% COMPLETE
          </div>
        </div>

        {/* Real-time Progress Bar */}
        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-indigo-600 to-violet-600 transition-all duration-300 ease-out"
            style={{ width: `${overallProgress}%` }}
          />
        </div>

        {/* Sequential Step Progression Cards */}
        <div className="space-y-2.5 text-left">
          {PHASES.map((phase, idx) => {
            const isDone = completedPhases.includes(idx);
            const isCurrent = activePhaseIndex === idx && !isDone;

            return (
              <div
                key={idx}
                className={`p-3 sm:p-3.5 rounded-2xl border transition-all duration-300 flex items-center justify-between gap-3 ${
                  isDone
                    ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950'
                    : isCurrent
                    ? 'bg-white border-indigo-500 shadow-xs ring-2 ring-indigo-100 text-slate-900'
                    : 'bg-white/50 border-slate-100 text-slate-400 opacity-60'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="shrink-0">
                    {isDone ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    ) : isCurrent ? (
                      <Loader2 className="w-5 h-5 text-indigo-600 animate-spin" />
                    ) : (
                      <div className="w-5 h-5 rounded-full border border-slate-200 flex items-center justify-center text-[10px] text-slate-400 font-bold">
                        {idx + 1}
                      </div>
                    )}
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs sm:text-sm font-bold truncate">{phase.title}</p>
                    <p className="text-[11px] text-slate-500 truncate">{phase.detail}</p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  {isDone && (
                    <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-md">
                      Verified
                    </span>
                  )}
                  {isCurrent && (
                    <span className="text-[10px] font-mono font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md animate-pulse">
                      Processing
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

      </div>

      {/* Manual advance if user doesn't want to wait */}
      {isFinished && (
        <button
          onClick={onComplete}
          className="px-8 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition-all flex items-center gap-2 animate-in fade-in"
        >
          <span>Reveal My CareerTwin →</span>
        </button>
      )}

    </div>
  );
};
