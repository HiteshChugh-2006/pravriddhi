import React, { useState } from 'react';
import { Target, ArrowRight, ArrowLeft, CheckCircle2, TrendingUp, Sparkles, Briefcase, Award } from 'lucide-react';

export interface CareerRoleOption {
  id: string;
  title: string;
  category: string;
  medianComp: string;
  growth: string;
  description: string;
  requiredSkills: string[];
}

export const ONBOARDING_ROLES: CareerRoleOption[] = [
  {
    id: 'role_mle',
    title: 'ML Engineer',
    category: 'Core AI/ML',
    medianComp: '$198,000',
    growth: '+42% YoY',
    description: 'Design, train, and deploy production machine learning pipelines and real-time inference microservices.',
    requiredSkills: ['Python', 'Deep Learning (PyTorch)', 'Machine Learning', 'FastAPI', 'MLOps & CI/CD', 'Docker & Containers']
  },
  {
    id: 'role_aie',
    title: 'AI Engineer',
    category: 'Emerging Tech',
    medianComp: '$212,000',
    growth: '+142% YoY',
    description: 'Build enterprise frontier model systems, multi-agent swarms, vector retrieval pipelines, and evaluations.',
    requiredSkills: ['Python', 'Deep Learning (PyTorch)', 'RAG & Vector Retrieval', 'AI Agents (LangGraph)', 'LLM Fine-tuning (LoRA)', 'FastAPI']
  },
  {
    id: 'role_ds',
    title: 'Data Scientist',
    category: 'Data & Analytics',
    medianComp: '$168,000',
    growth: '+28% YoY',
    description: 'Transform complex enterprise data into predictive mathematical models and strategic decision intelligence.',
    requiredSkills: ['Python', 'SQL', 'Data Science', 'Machine Learning', 'Pandas & NumPy', 'Data Visualization']
  },
  {
    id: 'role_fsd',
    title: 'Full Stack Developer',
    category: 'Full Stack & Web',
    medianComp: '$155,000',
    growth: '+24% YoY',
    description: 'Engineer responsive web applications, robust REST/GraphQL APIs, and database architectures.',
    requiredSkills: ['React', 'TypeScript', 'Node.js', 'FastAPI', 'SQL', 'Docker & Containers']
  },
  {
    id: 'role_swe',
    title: 'Software Engineer',
    category: 'Software & Infrastructure',
    medianComp: '$165,000',
    growth: '+20% YoY',
    description: 'Build scalable distributed backend systems, microservice backbones, and high-performance algorithms.',
    requiredSkills: ['Java', 'C++', 'Python', 'Docker & Containers', 'SQL', 'Kubernetes']
  },
  {
    id: 'role_da',
    title: 'Data Analyst',
    category: 'Data & Analytics',
    medianComp: '$115,000',
    growth: '+18% YoY',
    description: 'Build robust BI dashboards, optimize analytical data models, and conduct rigorous A/B experimentation.',
    requiredSkills: ['SQL', 'Data Visualization', 'Pandas & NumPy', 'Python', 'Data Science']
  }
];

interface CareerGoalStepProps {
  selectedRoleTitle: string;
  setSelectedRoleTitle: (title: string) => void;
  onNext: () => void;
  onBack: () => void;
}

export const CareerGoalStep: React.FC<CareerGoalStepProps> = ({
  selectedRoleTitle,
  setSelectedRoleTitle,
  onNext,
  onBack
}) => {
  const [customRoleInput, setCustomRoleInput] = useState('');
  const [error, setError] = useState<string | null>(null);

  const selectedRole = ONBOARDING_ROLES.find(
    (r) => r.title.toLowerCase() === selectedRoleTitle.toLowerCase()
  ) || ONBOARDING_ROLES[0];

  const handleSelectRole = (title: string) => {
    setSelectedRoleTitle(title);
    setError(null);
  };

  const handleAddCustomRole = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customRoleInput.trim()) return;
    setSelectedRoleTitle(customRoleInput.trim());
    setCustomRoleInput('');
    setError(null);
  };

  const handleContinue = () => {
    if (!selectedRoleTitle.trim()) {
      setError('Please select or specify a target career goal.');
      return;
    }
    setError(null);
    onNext();
  };

  return (
    <div className="max-w-4xl mx-auto py-4 px-4 space-y-6 animate-in fade-in duration-300">
      
      {/* Step Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-100 text-xs font-semibold text-indigo-700">
          <Target className="w-3.5 h-3.5" />
          <span>Screen 4 of 7 · Career Goal</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          What do you want to become?
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 max-w-lg mx-auto">
          Choose your target role. Pravriddhi will benchmark your current skills against live industry requirements for this position.
        </p>
      </div>

      {error && (
        <div className="max-w-md mx-auto p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs font-medium text-center">
          {error}
        </div>
      )}

      {/* Interactive Career Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
        {ONBOARDING_ROLES.map((role) => {
          const isSelected = selectedRoleTitle.toLowerCase() === role.title.toLowerCase();

          return (
            <button
              key={role.id}
              type="button"
              onClick={() => handleSelectRole(role.title)}
              className={`p-4 rounded-3xl border text-left transition-all duration-200 flex flex-col justify-between gap-3 relative overflow-hidden group cursor-pointer ${
                isSelected
                  ? 'bg-gradient-to-b from-indigo-50/90 via-white to-indigo-50/50 border-indigo-600 shadow-md ring-2 ring-indigo-500/20 scale-[1.02]'
                  : 'bg-white hover:bg-slate-50/80 border-slate-200/90 hover:border-indigo-200 shadow-2xs'
              }`}
            >
              <div>
                <div className="flex items-center justify-between text-[10px] text-slate-400 font-semibold mb-1">
                  <span>{role.category}</span>
                  <span className="text-emerald-700 font-mono font-bold">{role.growth}</span>
                </div>
                <div className="flex items-center justify-between gap-1">
                  <h4 className="font-bold text-sm sm:text-base text-slate-900 group-hover:text-indigo-600 transition-colors">
                    {role.title}
                  </h4>
                  {isSelected && (
                    <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                  )}
                </div>
                <p className="text-[11px] text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                  {role.description}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="font-mono font-bold text-slate-800">{role.medianComp}</span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    isSelected
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 text-slate-600 group-hover:bg-indigo-50 group-hover:text-indigo-600'
                  }`}
                >
                  {isSelected ? 'Selected Goal' : 'Select'}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Target Role Animate-In Beacon Preview */}
      {selectedRole && (
        <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-indigo-600 via-indigo-700 to-violet-700 text-white shadow-lg shadow-indigo-600/15 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-xs flex items-center justify-center text-white ring-4 ring-white/10 shrink-0">
              <Target className="w-6 h-6 text-indigo-200" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-200 block">
                Target Role Connected to CareerTwin
              </span>
              <h3 className="text-base sm:text-lg font-bold">{selectedRoleTitle}</h3>
              <p className="text-xs text-indigo-100 mt-0.5">
                Key competencies needed: {selectedRole.requiredSkills.join(', ')}
              </p>
            </div>
          </div>
          <div className="text-right shrink-0">
            <span className="text-[10px] uppercase text-indigo-200 block font-semibold">Median Compensation</span>
            <span className="text-lg font-mono font-black">{selectedRole.medianComp}</span>
          </div>
        </div>
      )}

      {/* Navigation Controls */}
      <div className="pt-4 flex items-center justify-between border-t border-slate-200">
        <button
          onClick={onBack}
          className="px-5 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 font-semibold text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back</span>
        </button>

        <button
          onClick={handleContinue}
          className="px-7 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition-all flex items-center gap-2 group cursor-pointer"
        >
          <span>Calculate Skill Gap</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
        </button>
      </div>

    </div>
  );
};
