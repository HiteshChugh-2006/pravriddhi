import React, { useState } from 'react';
import {
  Layers,
  Search,
  Plus,
  X,
  ArrowRight,
  ArrowLeft,
  Sliders,
  Sparkles,
  Check,
  TrendingUp,
  Cpu,
  Trash2
} from 'lucide-react';
import { SkillCategory, SkillType } from '../../types';

export interface OnboardingSkill {
  name: string;
  category: SkillCategory;
  proficiency: number; // 0 - 100
  type: SkillType;
}

interface SkillsStepProps {
  userName: string;
  skills: OnboardingSkill[];
  setSkills: (skills: OnboardingSkill[]) => void;
  onNext: () => void;
  onBack: () => void;
}

const PRESET_LIBRARY: Array<{ name: string; category: SkillCategory; growth: string }> = [
  // Programming Languages
  { name: 'Python', category: 'Core AI/ML', growth: '+28%' },
  { name: 'Java', category: 'Software & Infrastructure', growth: '+12%' },
  { name: 'C++', category: 'Software & Infrastructure', growth: '+18%' },
  { name: 'TypeScript', category: 'Software & Infrastructure', growth: '+34%' },
  { name: 'SQL', category: 'Data & Analytics', growth: '+15%' },

  // AI & Machine Learning
  { name: 'Machine Learning', category: 'Core AI/ML', growth: '+42%' },
  { name: 'Deep Learning (PyTorch)', category: 'Core AI/ML', growth: '+64%' },
  { name: 'Scikit-Learn', category: 'Core AI/ML', growth: '+20%' },
  { name: 'RAG & Vector Retrieval', category: 'Emerging Tech', growth: '+128%' },
  { name: 'AI Agents (LangGraph)', category: 'Emerging Tech', growth: '+98%' },
  { name: 'LLM Fine-tuning (LoRA)', category: 'Emerging Tech', growth: '+114%' },

  // Full Stack & Web
  { name: 'React', category: 'Software & Infrastructure', growth: '+22%' },
  { name: 'Node.js', category: 'Software & Infrastructure', growth: '+19%' },
  { name: 'FastAPI', category: 'Software & Infrastructure', growth: '+52%' },
  { name: 'Next.js', category: 'Software & Infrastructure', growth: '+38%' },

  // Data & Analytics
  { name: 'Data Science', category: 'Data & Analytics', growth: '+32%' },
  { name: 'Pandas & NumPy', category: 'Data & Analytics', growth: '+24%' },
  { name: 'Data Visualization', category: 'Data & Analytics', growth: '+14%' },
  { name: 'Snowflake', category: 'Data & Analytics', growth: '+45%' },

  // Cloud & DevOps
  { name: 'Docker & Containers', category: 'Software & Infrastructure', growth: '+41%' },
  { name: 'Kubernetes', category: 'Software & Infrastructure', growth: '+39%' },
  { name: 'MLOps & CI/CD', category: 'Software & Infrastructure', growth: '+78%' },
  { name: 'Cloud (AWS/GCP)', category: 'Cloud & Systems', growth: '+36%' }
];

export const SkillsStep: React.FC<SkillsStepProps> = ({
  userName,
  skills,
  setSkills,
  onNext,
  onBack
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [customInput, setCustomInput] = useState('');
  const [selectedSkillForFocus, setSelectedSkillForFocus] = useState<string | null>(
    skills[0]?.name || null
  );
  const [error, setError] = useState<string | null>(null);

  const toggleSkill = (skillName: string, category: SkillCategory = 'Core AI/ML') => {
    const existingIndex = skills.findIndex(
      (s) => s.name.toLowerCase() === skillName.toLowerCase()
    );

    if (existingIndex >= 0) {
      setSkills(skills.filter((_, i) => i !== existingIndex));
      if (selectedSkillForFocus?.toLowerCase() === skillName.toLowerCase()) {
        setSelectedSkillForFocus(null);
      }
    } else {
      const newSkill: OnboardingSkill = {
        name: skillName,
        category,
        proficiency: 75,
        type: 'demonstrated'
      };
      setSkills([...skills, newSkill]);
      setSelectedSkillForFocus(skillName);
      setError(null);
    }
  };

  const handleAddCustomSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customInput.trim()) return;
    const nameTrimmed = customInput.trim();
    if (skills.some((s) => s.name.toLowerCase() === nameTrimmed.toLowerCase())) {
      setCustomInput('');
      return;
    }
    toggleSkill(nameTrimmed, 'Software & Infrastructure');
    setCustomInput('');
  };

  const handleSetProficiency = (skillName: string, level: number) => {
    setSkills(
      skills.map((s) =>
        s.name.toLowerCase() === skillName.toLowerCase() ? { ...s, proficiency: level } : s
      )
    );
  };

  const handleContinue = () => {
    if (skills.length === 0) {
      setError('Please select or add at least one skill to map into your CareerTwin.');
      return;
    }
    setError(null);
    onNext();
  };

  const filteredPreset = PRESET_LIBRARY.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat =
      selectedCategory === 'All' ||
      (selectedCategory === 'Languages' && ['Python', 'Java', 'C++', 'TypeScript', 'SQL'].includes(item.name)) ||
      (selectedCategory === 'AI / ML' && item.category === 'Core AI/ML') ||
      (selectedCategory === 'Emerging Tech' && item.category === 'Emerging Tech') ||
      (selectedCategory === 'Data' && item.category === 'Data & Analytics') ||
      (selectedCategory === 'Cloud / Infra' && (item.category === 'Software & Infrastructure' || item.category === 'Cloud & Systems'));
    return matchesSearch && matchesCat;
  });

  const activeFocusedSkill = skills.find(
    (s) => s.name.toLowerCase() === selectedSkillForFocus?.toLowerCase()
  );

  return (
    <div className="max-w-5xl mx-auto py-4 px-4 space-y-6 animate-in fade-in duration-300">
      
      {/* Step Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-100 text-xs font-semibold text-indigo-700">
          <Layers className="w-3.5 h-3.5" />
          <span>Screen 3 of 7 · Your Skills</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          What are your core technical capabilities?
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 max-w-xl mx-auto">
          Add skills to connect them directly to your central "You" node. Adjust proficiency to model your verified technical depth.
        </p>
      </div>

      {error && (
        <div className="max-w-md mx-auto p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs font-medium text-center">
          {error}
        </div>
      )}

      {/* Main Grid: Interactive Connected Node Graph (Left) & Skill Selector/Search (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Visual Connected Nodes Graph (7 cols) */}
        <div className="lg:col-span-7 bg-gradient-to-b from-slate-50/80 via-white to-indigo-50/40 rounded-3xl p-6 border border-slate-200/90 shadow-sm relative min-h-[380px] flex flex-col justify-between overflow-hidden">
          
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <span className="text-xs font-bold text-slate-800 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-indigo-600" />
              <span>CareerTwin Skill Network</span>
            </span>
            <span className="text-xs font-mono font-bold text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-full border border-indigo-100">
              {skills.length} Connected {skills.length === 1 ? 'Node' : 'Nodes'}
            </span>
          </div>

          {/* SVG / Dynamic Radial Node Canvas */}
          <div className="relative my-4 flex-1 flex items-center justify-center min-h-[260px]">
            {/* Center "You" node */}
            <div className="relative z-20 flex flex-col items-center">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 text-white flex items-center justify-center font-extrabold text-base shadow-xl shadow-indigo-600/30 ring-4 ring-indigo-50 animate-pulse">
                You
              </div>
              <span className="text-[10px] font-bold text-slate-700 mt-1.5 uppercase tracking-wider">
                {userName ? userName.split(' ')[0] : 'Identity Core'}
              </span>
            </div>

            {/* Orbiting Selected Skill Nodes */}
            {skills.length === 0 ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 bg-white/40 backdrop-blur-2xs rounded-2xl border border-dashed border-slate-200">
                <Sparkles className="w-8 h-8 text-indigo-400 mb-2 animate-bounce" />
                <p className="text-xs font-bold text-slate-700">No Skills Connected Yet</p>
                <p className="text-[11px] text-slate-400 max-w-xs mt-1">
                  Select or search skills on the right to animate connected competency nodes to your profile.
                </p>
              </div>
            ) : (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                {skills.map((skill, idx) => {
                  const total = skills.length;
                  const angle = (idx / total) * 2 * Math.PI - Math.PI / 2;
                  const radius = total > 6 ? 125 : 105;
                  const x = Math.cos(angle) * radius;
                  const y = Math.sin(angle) * radius;
                  const isFocused = selectedSkillForFocus === skill.name;

                  return (
                    <div
                      key={skill.name}
                      style={{
                        transform: `translate(${x}px, ${y}px)`
                      }}
                      className="absolute z-10 pointer-events-auto transition-transform duration-300"
                    >
                      <button
                        type="button"
                        onClick={() => setSelectedSkillForFocus(skill.name)}
                        className={`px-3 py-1.5 rounded-xl border text-left transition-all duration-200 shadow-2xs flex items-center gap-1.5 group cursor-pointer ${
                          isFocused
                            ? 'bg-indigo-600 text-white border-indigo-600 scale-105 shadow-md shadow-indigo-600/25 ring-2 ring-indigo-300'
                            : 'bg-white hover:bg-indigo-50/80 text-slate-800 border-slate-200 hover:border-indigo-300'
                        }`}
                      >
                        <span className="text-[11px] font-bold truncate max-w-[100px]">{skill.name}</span>
                        <span
                          className={`text-[9px] font-mono px-1 rounded-sm ${
                            isFocused ? 'bg-indigo-700 text-white' : 'bg-slate-100 text-slate-500'
                          }`}
                        >
                          {skill.proficiency}%
                        </span>
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Focused Skill Proficiency Controller */}
          {activeFocusedSkill && (
            <div className="p-3.5 rounded-2xl bg-white border border-indigo-100 shadow-xs space-y-2">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 font-bold text-slate-900">
                  <Sliders className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Proficiency: {activeFocusedSkill.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-mono font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md">
                    {activeFocusedSkill.proficiency}% · {
                      activeFocusedSkill.proficiency >= 85
                        ? 'Advanced / Expert'
                        : activeFocusedSkill.proficiency >= 65
                        ? 'Practitioner'
                        : 'Foundational'
                    }
                  </span>
                  <button
                    onClick={() => toggleSkill(activeFocusedSkill.name)}
                    className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                    title="Remove Skill"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <input
                type="range"
                min="35"
                max="98"
                value={activeFocusedSkill.proficiency}
                onChange={(e) => handleSetProficiency(activeFocusedSkill.name, Number(e.target.value))}
                aria-label={`Proficiency slider for ${activeFocusedSkill.name}`}
                className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
            </div>
          )}

        </div>

        {/* Skill Search & Library Picker (5 cols) */}
        <div className="lg:col-span-5 space-y-4 bg-white/90 rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-xs">
          
          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search e.g. Python, React, SQL..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50/50 text-xs text-slate-900 placeholder:text-slate-400 focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-hidden"
            />
          </div>

          {/* Quick Categories */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px]">
            {['All', 'Languages', 'AI / ML', 'Emerging Tech', 'Data', 'Cloud / Infra'].map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Interactive Skill Pills Grid */}
          <div className="grid grid-cols-2 gap-2 max-h-52 overflow-y-auto pr-1">
            {filteredPreset.map((item) => {
              const isSelected = skills.some(
                (s) => s.name.toLowerCase() === item.name.toLowerCase()
              );
              return (
                <button
                  key={item.name}
                  type="button"
                  onClick={() => toggleSkill(item.name, item.category)}
                  className={`p-2.5 rounded-xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
                    isSelected
                      ? 'bg-indigo-50 border-indigo-500 text-indigo-950 font-bold shadow-2xs ring-1 ring-indigo-500'
                      : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="truncate">{item.name}</span>
                    {isSelected ? (
                      <Check className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    ) : (
                      <Plus className="w-3.5 h-3.5 text-slate-400 group-hover:text-indigo-600 shrink-0" />
                    )}
                  </div>
                  <span className="text-[10px] text-emerald-700 font-mono font-semibold mt-1">
                    {item.growth} demand
                  </span>
                </button>
              );
            })}
          </div>

          {/* Add Custom Skill */}
          <form onSubmit={handleAddCustomSkill} className="pt-2 border-t border-slate-100 flex items-center gap-2">
            <input
              type="text"
              value={customInput}
              onChange={(e) => setCustomInput(e.target.value)}
              placeholder="Add custom skill (e.g. Rust, Go, GraphQL)..."
              className="flex-1 px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 text-xs focus:bg-white focus:border-indigo-500 outline-hidden"
            />
            <button
              type="submit"
              disabled={!customInput.trim()}
              className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition-colors disabled:opacity-40 flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add</span>
            </button>
          </form>

        </div>

      </div>

      {/* Navigation Controls */}
      <div className="pt-4 flex items-center justify-between border-t border-slate-200">
        <button
          onClick={onBack}
          className="px-5 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 font-semibold text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back</span>
        </button>

        <button
          onClick={handleContinue}
          className="px-7 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition-all flex items-center gap-2 group cursor-pointer"
        >
          <span>Continue to Career Goal</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
        </button>
      </div>

    </div>
  );
};
