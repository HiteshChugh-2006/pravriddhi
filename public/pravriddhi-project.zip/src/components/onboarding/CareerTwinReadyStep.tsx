import React from 'react';
import {
  Sparkles,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  Target,
  TrendingUp,
  Cpu,
  GraduationCap,
  Briefcase,
  MapPin,
  ExternalLink
} from 'lucide-react';
import { OnboardingSkill } from './SkillsStep';
import { ONBOARDING_ROLES } from './CareerGoalStep';

interface CareerTwinReadyStepProps {
  name: string;
  degree: string;
  education: string;
  gradYear: string;
  experienceLevel: string;
  location: string;
  skills: OnboardingSkill[];
  targetRoleTitle: string;
  onEnterDashboard: () => void;
}

export const CareerTwinReadyStep: React.FC<CareerTwinReadyStepProps> = ({
  name,
  degree,
  education,
  gradYear,
  experienceLevel,
  location,
  skills,
  targetRoleTitle,
  onEnterDashboard
}) => {
  const targetRole = ONBOARDING_ROLES.find(
    (r) => r.title.toLowerCase() === targetRoleTitle.toLowerCase()
  ) || ONBOARDING_ROLES[0];

  const strongSkills = targetRole.requiredSkills.filter((req) =>
    skills.some((s) => s.name.toLowerCase() === req.toLowerCase() && s.proficiency >= 65)
  );

  const developingSkills = targetRole.requiredSkills.filter((req) =>
    skills.some((s) => s.name.toLowerCase() === req.toLowerCase() && s.proficiency < 65)
  );

  const missingSkills = targetRole.requiredSkills.filter(
    (req) => !skills.some((s) => s.name.toLowerCase() === req.toLowerCase())
  );

  const totalRequired = Math.max(1, targetRole.requiredSkills.length);
  const alignmentScore = Math.min(
    96,
    Math.max(
      20,
      Math.round(((strongSkills.length * 1.0 + developingSkills.length * 0.5) / totalRequired) * 100)
    )
  );

  const getInitials = (n: string) => {
    if (!n.trim()) return 'CT';
    const parts = n.trim().split(/\s+/);
    if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
    return n.slice(0, 2).toUpperCase();
  };

  const topMissing = missingSkills[0] || 'MLOps & CI/CD';

  return (
    <div className="max-w-3xl mx-auto py-6 px-4 space-y-8 text-center animate-in fade-in duration-300">
      
      {/* Celebration Header */}
      <div className="space-y-2">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-50 border border-emerald-200 text-xs font-semibold text-emerald-800 shadow-2xs">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Digital Twin Successfully Synthesized</span>
        </div>

        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Your CareerTwin is ready.
        </h1>

        <p className="text-xs sm:text-sm text-slate-500 max-w-lg mx-auto">
          Pravriddhi has constructed your evidence-verified competency graph and mapped your personalized trajectory to <strong>{targetRole.title}</strong>.
        </p>
      </div>

      {/* Interactive CareerTwin Summary Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-indigo-50/70 via-white to-violet-50/60 border border-indigo-100 shadow-xl text-left space-y-6">
        
        {/* Profile Identity Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-200/80">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 text-white font-black text-2xl flex items-center justify-center shadow-lg shadow-indigo-600/20 ring-4 ring-indigo-50 shrink-0">
              {getInitials(name)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-slate-900 text-lg sm:text-xl">
                  {name || 'Alex Morgan'}
                </h3>
                <span className="text-[10px] bg-emerald-500 text-white font-bold px-2 py-0.5 rounded-full">
                  Twin Active
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5 font-medium">
                {degree} · {education} ({gradYear})
              </p>
              <p className="text-[11px] text-slate-400">
                {experienceLevel} · {location || 'Remote'}
              </p>
            </div>
          </div>

          <div className="text-left sm:text-right shrink-0">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
              Target Career Goal
            </span>
            <span className="text-base font-extrabold text-indigo-700 block">
              {targetRole.title}
            </span>
            <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100 mt-1 inline-block">
              {alignmentScore}% Career Alignment
            </span>
          </div>
        </div>

        {/* 3 Metrics Overview */}
        <div className="grid grid-cols-3 gap-3 text-center">
          <div className="p-3.5 rounded-2xl bg-white border border-slate-100 shadow-2xs">
            <span className="text-[10px] text-slate-400 font-semibold block uppercase">Total Skills</span>
            <span className="text-xl font-bold font-mono text-slate-900">{skills.length}</span>
          </div>
          <div className="p-3.5 rounded-2xl bg-white border border-slate-100 shadow-2xs">
            <span className="text-[10px] text-slate-400 font-semibold block uppercase">Strong Matches</span>
            <span className="text-xl font-bold font-mono text-emerald-600">{strongSkills.length}</span>
          </div>
          <div className="p-3.5 rounded-2xl bg-white border border-slate-100 shadow-2xs">
            <span className="text-[10px] text-slate-400 font-semibold block uppercase">Skill Gaps</span>
            <span className="text-xl font-bold font-mono text-amber-600">{missingSkills.length}</span>
          </div>
        </div>

        {/* Breakdown Sections */}
        <div className="space-y-4 text-xs">
          
          {/* Strong Skills */}
          <div>
            <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block mb-2">
              Verified Strong Competencies:
            </span>
            <div className="flex flex-wrap gap-2">
              {strongSkills.length > 0 ? (
                strongSkills.map((s) => (
                  <span
                    key={s}
                    className="px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-950 font-bold border border-emerald-200 flex items-center gap-1.5 shadow-2xs"
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{s}</span>
                  </span>
                ))
              ) : (
                skills.slice(0, 3).map((s) => (
                  <span
                    key={s.name}
                    className="px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-950 font-bold border border-emerald-200"
                  >
                    {s.name}
                  </span>
                ))
              )}
            </div>
          </div>

          {/* Developing Skills */}
          {developingSkills.length > 0 && (
            <div>
              <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block mb-2">
                Developing Skills:
              </span>
              <div className="flex flex-wrap gap-2">
                {developingSkills.map((s) => (
                  <span
                    key={s}
                    className="px-3 py-1.5 rounded-xl bg-sky-50 text-sky-950 font-medium border border-sky-200"
                  >
                    {s} (In Progress)
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Missing Skills */}
          {missingSkills.length > 0 && (
            <div>
              <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block mb-2">
                Identified Skill Gaps:
              </span>
              <div className="flex flex-wrap gap-2">
                {missingSkills.map((s) => (
                  <span
                    key={s}
                    className="px-3 py-1.5 rounded-xl bg-amber-50 text-amber-950 font-medium border border-amber-200"
                  >
                    ○ {s}
                  </span>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Recommended Next Step Callout */}
        <div className="p-4 rounded-2xl bg-indigo-50/90 border border-indigo-200/90 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-slate-900 block">Recommended First Action:</span>
              <span className="text-slate-600">
                Run a What-If simulation for <strong>{topMissing}</strong> in your new Dashboard to simulate closing your top gap.
              </span>
            </div>
          </div>
          <span className="text-indigo-700 font-bold whitespace-nowrap text-xs">
            Project +14% Fit →
          </span>
        </div>

      </div>

      {/* Final Action CTA: Enter My Career Dashboard */}
      <div className="pt-2">
        <button
          onClick={onEnterDashboard}
          className="w-full sm:w-auto px-10 py-4 rounded-2xl bg-gradient-to-r from-indigo-600 via-indigo-700 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white font-extrabold text-sm sm:text-base shadow-xl shadow-indigo-600/25 hover:shadow-2xl transition-all flex items-center justify-center gap-3 mx-auto group cursor-pointer"
        >
          <span>Enter My Career Dashboard</span>
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1.5 transition-transform" />
        </button>
        <p className="text-[11px] text-slate-400 mt-2">
          Your profile and skills have been securely saved to your isolated account vault.
        </p>
      </div>

    </div>
  );
};
